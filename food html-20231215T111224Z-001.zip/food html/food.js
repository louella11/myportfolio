
let quantity = 1;
let itemName = "";
let itemPrice = 0;

function add() {
    quantity++;
    updateQuantity();
}

function minus() {
    if (quantity > 0) {
        quantity--;
        updateQuantity();
    }
}

function updateQuantity() {
    const quantityElement = document.querySelector('.rating span');
    if (quantityElement) {
        quantityElement.textContent = quantity;
    }
}

function addToCart() {
    if (itemName !== "") {
        const total = quantity * itemPrice;
        const orderDetails = {
            itemName: itemName,
            itemPrice: itemPrice,
            quantity: quantity,
            total: total
        };

        let orders = JSON.parse(localStorage.getItem('orders')) || [];
        orders.push(orderDetails);
        localStorage.setItem('orders', JSON.stringify(orders));


        updateCart();
        const alertMessage = `Added to Cart:\n${quantity} x ${itemName} - ${total} pesos`;
        alert(`${alertMessage}\n\nOrder successfully added to the cart!`);
    } else {
        alert('Item name or price not set. Cannot add to cart.');
    }
}

function updateCart() {
    const cartElement = document.getElementById('cart');
    if (cartElement) {
        cartElement.innerHTML = '<h1>CART BOX</h1>';

        const orders = JSON.parse(localStorage.getItem('orders')) || [];

        orders.forEach(order => {
            const orderItem = document.createElement('div');
            orderItem.innerHTML = `
                <p>${order.quantity} x ${order.itemName} - ${order.total} pesos</p>
            `;
            cartElement.appendChild(orderItem);
        });
    }
}